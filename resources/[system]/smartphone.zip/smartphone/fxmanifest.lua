fx_version 'adamant'
game 'gta5'

server_scripts {
    'server.js'
}

client_scripts {
    'client.lua'
}

ui_page 'index.html'

files {
    'index.html'
}